import Foundation

class KeyGenerator {
    
    // Start in 0
    private var currentKey: Int = 0
    
    func generate() -> Int {
        // Will always start from 1
        currentKey += 1
        return currentKey
    }
}
