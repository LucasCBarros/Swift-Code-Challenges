import Foundation

class Television: Eletronic {
    // starting from 1
    var keyGenerator = KeyGenerator()
    
    // Everytime Generate is called will increment by 1
    var id: Int
    
    // Is an ENUM
    var manufacturer: Manufacturer
    
    init(manufacturer: Manufacturer) {
        self.id = keyGenerator.generate()
        self.manufacturer = manufacturer
    }
}

class Phone: Eletronic {
    
    // starting from 1
    var keyGenerator = KeyGenerator()
    
    var id: Int
    
    var manufacturer: Manufacturer
    var OperationSystem: OS = .ios
    
    init(manufacturer: Manufacturer) throws {
        
        self.id = keyGenerator.generate()
        switch manufacturer {
        case .apple:
            OperationSystem = .ios
            self.manufacturer = .apple
        case .samsung:
            OperationSystem = .android
            self.manufacturer = .samsung
        case.lg:
            OperationSystem = .android
            self.manufacturer = .lg
        case .google:
            OperationSystem = .android
            self.manufacturer = .google
        default:
            print("The \(manufacturer) doesn't make phones")
            OperationSystem = .android
            self.manufacturer = .google
        }
    }
}

protocol Eletronic {
    var id: Int { get set }
    var keyGenerator: KeyGenerator { get set }
    var manufacturer: Manufacturer { get set }
    var OperationSystem: Manufacturer { get set }
}

enum OS {
    case ios
    case android
}
