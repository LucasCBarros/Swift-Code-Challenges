import Foundation

class Inventory {
    private var items: [Eletronic] = []
    
    // Adds item of the enum case of type television
    func addItem(item: Eletronic) {
        items.append(item)
    }
    
    // Remove all eletronics with the same ID as passed
    func removeItem(item: Eletronic) {
        items.removeAll { $0.id == item.id }
    }
    
    // Retrieve all items saved
    func getItems() -> [Eletronic] {
        return items
    }
}

