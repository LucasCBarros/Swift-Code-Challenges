package com.example.myapplication.inventory

import com.example.myapplication.items.Television

class Inventory {
    private val items: MutableList<Television> = mutableListOf()

    fun addItem(item: Television) {
        items.add(item)
    }

    fun removeItem(item: Television) {
        items.remove(item)
    }

    fun getItems(): List<Television> {
        return items
    }
}
