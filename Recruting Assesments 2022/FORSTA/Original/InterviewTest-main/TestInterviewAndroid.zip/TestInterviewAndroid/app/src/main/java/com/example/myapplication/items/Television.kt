package com.example.myapplication.items

import com.example.myapplication.Manufacturer
import com.example.myapplication.framework.KeyGenerator

class Television(val manufacturer: Manufacturer) {
    companion object {
        private val keyGenerator = KeyGenerator()
    }

    val id = keyGenerator.generate()
}
