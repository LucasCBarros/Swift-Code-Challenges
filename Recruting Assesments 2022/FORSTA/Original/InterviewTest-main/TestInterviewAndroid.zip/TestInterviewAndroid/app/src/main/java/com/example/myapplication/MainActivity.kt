package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.example.myapplication.inventory.Inventory
import com.example.myapplication.items.Television

class MainActivity : AppCompatActivity() {
    private lateinit var layRoot: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        layRoot = LinearLayout(this)
        setContentView(layRoot)

        layRoot.orientation = LinearLayout.VERTICAL

        val inventory = Inventory()
        for (manu in Manufacturer.values()) {
            inventory.addItem(Television(manu))
        }

        loadInventory(inventory)
    }

    private fun loadInventory(inventory: Inventory) {
        for (item in inventory.getItems()) {
            val itemView = loadItem(item)
            layRoot.addView(
                itemView,
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }
    }

    private fun loadItem(item: Television): ViewGroup {
        val layItemContainer = LinearLayout(this)
        layItemContainer.orientation = LinearLayout.HORIZONTAL

        val txtId = TextView(this)
        txtId.text = item.id.toString()

        var params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT)
        params.weight = 1f
        layItemContainer.addView(txtId, params)

        val txtManu = TextView(this)
        txtManu.text = item.manufacturer.value

        params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT)
        params.weight = 1f
        layItemContainer.addView(txtManu, params)

        return layItemContainer
    }


}