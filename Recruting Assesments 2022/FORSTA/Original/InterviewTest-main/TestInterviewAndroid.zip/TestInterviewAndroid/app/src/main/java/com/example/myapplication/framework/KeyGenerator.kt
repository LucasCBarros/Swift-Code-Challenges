package com.example.myapplication.framework

class KeyGenerator {
    private var currentKey: Int = 0

    fun generate(): Int {
        currentKey++
        return currentKey
    }
}
