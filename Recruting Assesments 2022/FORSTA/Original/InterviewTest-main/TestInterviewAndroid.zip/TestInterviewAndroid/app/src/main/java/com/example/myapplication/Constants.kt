package com.example.myapplication

enum class Manufacturer(val value: String) {
    SAMSUNG("Samsung"), LG("LG"), SONY("Sony"), ACER("Acer"), INSIGNIA("Insignia"), TOSHIBA("Toshiba")
}
