﻿using System;
using InterviewTest.Framework;

namespace InterviewTest.Items
{
    internal class Television : IPrintable
    {
        private static readonly KeyGenerator _keyGenerator = new KeyGenerator();

        private readonly int _id;
        private readonly string _manufacturer;

        public Television(string manufacturer)
        {
            _id = _keyGenerator.Generate();
            _manufacturer = manufacturer;
        }

        public void Print()
        {
            Console.WriteLine("Type: Television - ID: {0} - Manufacturer: {1}", _id, _manufacturer);
        }
    }
}
