﻿namespace InterviewTest.Framework
{
    public class KeyGenerator
    {
        private int _currentKey;

        public KeyGenerator()
        {
            _currentKey = 0;
        }

        public int Generate()
        {
            _currentKey++;

            return _currentKey;
        }
    }
}
