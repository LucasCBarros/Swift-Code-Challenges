﻿namespace InterviewTest.Framework
{
    internal interface IPrintable
    {
        void Print();
    }
}
