﻿using System;
using InterviewTest.Framework;
using System.Collections.Generic;

namespace InterviewTest.Inventory
{
    internal class Inventory<T> where T : IPrintable
    {
        private static bool _isInventoryCreated = false;

        private readonly List<T> _items;        

        public Inventory()
        {
            if (_isInventoryCreated)
            {
                throw new Exception("Can only have single instance of Inventory");
            }

            _items = new List<T>();
            _isInventoryCreated = true;
        }

        public void AddItem(T item)
        {
            _items.Add(item);
        }

        public void RemoveItem(T item)
        {
            _items.Remove(item);
        }

        public void Print()
        {
            foreach(var item in _items)
            {
                item.Print();
            }
        }
    }
}
