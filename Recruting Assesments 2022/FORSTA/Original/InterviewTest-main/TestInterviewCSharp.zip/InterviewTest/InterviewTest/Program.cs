﻿using InterviewTest.Inventory;
using InterviewTest.Items;
using System;

namespace InterviewTest
{
    internal class Program
    {
        private static void Main(string[] args)
        {

            var inventory = new Inventory<Television>();
            inventory.AddItem(new Television("Samsung"));
            inventory.AddItem(new Television("LG"));
            inventory.AddItem(new Television("Sony"));

            inventory.Print();

            Console.ReadLine();
        }
    }
}
