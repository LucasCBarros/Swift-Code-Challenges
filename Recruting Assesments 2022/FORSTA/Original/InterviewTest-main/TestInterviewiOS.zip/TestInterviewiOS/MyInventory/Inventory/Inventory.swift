import Foundation

class Inventory {
  private var items: [Television] = []

  func addItem(item: Television) {
    items.append(item)
  }

  func removeItem(item: Television) {
    items.removeAll { $0.id == item.id }
  }

  func getItems() -> [Television] {
    return items
  }
}
