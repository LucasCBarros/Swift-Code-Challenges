import Foundation

class Television {
  private static let keyGenerator = KeyGenerator()
  
  let id = keyGenerator.generate()
  
  let manufacturer: Manufacturer
  
  init(manufacturer: Manufacturer) {
    self.manufacturer = manufacturer
  }
}
