import UIKit

class ViewController: UIViewController {
  private let rootStackView = UIStackView()

  override func viewDidLoad() {
    super.viewDidLoad()

    rootStackView.axis = NSLayoutConstraint.Axis.vertical
    view.addSubview(rootStackView)
    rootStackView.translatesAutoresizingMaskIntoConstraints = false
    let leadingCstr = NSLayoutConstraint(item: rootStackView,
                                         attribute: NSLayoutConstraint.Attribute.leading,
                                         relatedBy: NSLayoutConstraint.Relation.equal,
                                         toItem: view,
                                         attribute: NSLayoutConstraint.Attribute.leading,
                                         multiplier: 1, constant: 0)
    let trailingCstr = NSLayoutConstraint(item: rootStackView,
                                          attribute: NSLayoutConstraint.Attribute.trailing,
                                          relatedBy: NSLayoutConstraint.Relation.equal,
                                          toItem: view,
                                          attribute: NSLayoutConstraint.Attribute.trailing,
                                          multiplier: 1, constant: 0)
    let topCstr = NSLayoutConstraint(item: rootStackView,
                                     attribute: NSLayoutConstraint.Attribute.top,
                                     relatedBy: NSLayoutConstraint.Relation.equal,
                                     toItem: view,
                                     attribute: NSLayoutConstraint.Attribute.top,
                                     multiplier: 1, constant: 100)
    view.addConstraints([leadingCstr, trailingCstr, topCstr])

    let inventory = Inventory()
    for manu in Manufacturer.allCases {
      inventory.addItem(item: Television(manufacturer: manu))
    }

    loadInventory(inventory: inventory)
  }

  private func loadInventory(inventory: Inventory) {
    for item in inventory.getItems() {
      let itemView = loadItem(item: item)

      rootStackView.addArrangedSubview(itemView)
    }
  }

  private func loadItem(item: Television) -> UIStackView {
    let stackView = UIStackView()
    stackView.axis = NSLayoutConstraint.Axis.horizontal
    stackView.distribution = UIStackView.Distribution.fillEqually

    let txtId = UILabel()
    txtId.text = String(item.id)
    stackView.addArrangedSubview(txtId)

    let txtManu = UILabel()
    txtManu.text = item.manufacturer.rawValue
    stackView.addArrangedSubview(txtManu)

    return stackView
  }
}
