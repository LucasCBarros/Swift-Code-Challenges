import Foundation

enum Manufacturer: String, CaseIterable {
  case samsung = "Samsung"
  case lg = "LG"
  case sony = "Sony"
  case acer = "Acer"
  case insignia = "Insignia"
  case toshiba = "Toshiba"
}
