import Foundation

class KeyGenerator {
  private var currentKey: Int = 0

  func generate() -> Int {
    currentKey += 1
    return currentKey
  }
}
