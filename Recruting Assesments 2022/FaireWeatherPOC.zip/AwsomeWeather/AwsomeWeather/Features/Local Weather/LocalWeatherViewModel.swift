//
//  LocalWeatherViewModel.swift
//  AwsomeWeather
//
//  Created by Lucas C Barros on 01/05/22.
//

import Foundation

protocol LocalWeatherViewModelProtocol {
    var locationTitle: String? { get set }
    var weatherImage: String? { get set }
    var weatherDescription: String? { get set }
    
    var temperature: Float? { get set }
    var lowestTemperature: Float? { get set }
    var highestTemperature: Float? { get set }
    
    var requestError: WeatherRequestError? { get set }
}

class LocalWeatherViewModel: LocalWeatherViewModelProtocol {
    var locationTitle: String?
    var weatherImage: String?
    var weatherDescription: String?
    
    var temperature: Float?
    var lowestTemperature: Float?
    var highestTemperature: Float?
    
    var requestError: WeatherRequestError?
    
    init(locationID: String) {
        fetchLocalWeatherData(locationID: locationID)
    }
    
    func fetchLocalWeatherData(locationID: String) {
        // API Call
        let weatherDataRequest = GetWeatherDataRequest(locationID: locationID)
        weatherDataRequest.getLocalWeatherData { [weak self] result in
            switch result {
            case .failure(let error):
                self?.requestError = error
                
            case .success(let localData):
                self?.locationTitle = locationID
                self?.weatherImage = localData.weatherStateName
                self?.weatherDescription = localData.weatherStateName
                
                self?.temperature = localData.currentTemperature
                self?.lowestTemperature = localData.minimumTemperature
                self?.highestTemperature = localData.maximumTemperature
            }
        }
    }
}
