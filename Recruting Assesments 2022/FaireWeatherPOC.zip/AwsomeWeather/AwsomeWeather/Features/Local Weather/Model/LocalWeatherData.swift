//
//  LocalWeatherData.swift
//  AwsomeWeather
//
//  Created by Lucas C Barros on 01/05/22.
//

import Foundation

struct LocalWeatherData: Decodable {
    var id: Int
    var weatherStateName: String
    var currentTemperature: Float
    var maximumTemperature: Float
    var minimumTemperature: Float
    
    init(locatonID: Int, weatherName: String, currentTemperature: Float, minimumTemperature: Float, maximumTemperature: Float) {
        self.id = locatonID
        self.weatherStateName = weatherName
        self.currentTemperature = currentTemperature
        self.minimumTemperature = minimumTemperature
        self.maximumTemperature = maximumTemperature
    }
}

struct WorldWeatherData: Decodable {
    var allLocations: [LocalWeatherData]
}
