//
//  getWeatherDataRequest.swift
//  AwsomeWeather
//
//  Created by Lucas C Barros on 01/05/22.
//

import Foundation

enum WeatherRequestError: Error {
    case noDataAvailable
    case cantProcessData
    case timeout
}

struct GetWeatherDataRequest {
    private let resourceURL: URL

    init(locationID: String) {
        let resourcePath = "//www.metaweather.com/api/location/\(locationID)/"
        
        guard let resourceURL = URL(string: resourcePath) else { fatalError() }
        
        self.resourceURL = resourceURL
    }
    
    func getLocalWeatherData(completion: @escaping (Result<LocalWeatherData, WeatherRequestError>) -> Void) {
        let dataTask = URLSession.shared.dataTask(with: resourceURL) { data, _, _ in
            guard let jsonData = data else {
                completion(.failure(.noDataAvailable))
                return
            }
            do {
                let decoder = JSONDecoder()
                let weatherDataResponse = try decoder.decode(LocalWeatherData.self, from: jsonData)
                completion(.success(weatherDataResponse))
            } catch {
                completion(.failure(.cantProcessData))
            }
        }
        dataTask.resume()
    }
    
//    func getWeatherDataRequest() {
//
//    }
}
