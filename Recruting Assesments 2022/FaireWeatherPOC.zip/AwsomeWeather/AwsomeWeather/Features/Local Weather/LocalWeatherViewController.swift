//
//  LocalWeatherViewController.swift
//  AwsomeWeather
//
//  Created by Lucas C Barros on 01/05/22.
//

import UIKit

class LocalWeatherViewController: UIViewController {

    @IBOutlet weak var locationTitle: UILabel!
    @IBOutlet weak var weatherImage: UIImageView!
    @IBOutlet weak var weatherDescription: UILabel!
    
    @IBOutlet weak var temperature: UILabel!
    @IBOutlet weak var lowestTemperature: UILabel!
    @IBOutlet weak var highestTemperature: UILabel!
    
    var viewModel: LocalWeatherViewModelProtocol?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        viewModel = LocalWeatherViewModel(locationID: "4118")
        setupView()
    }

    func setupView() {
        if viewModel?.requestError == nil {
            locationTitle.text = "Vancouver"
            weatherDescription.text = viewModel?.weatherDescription
            
            temperature.text = String(describing: viewModel?.temperature)
            lowestTemperature.text = String(describing: viewModel?.lowestTemperature)
            highestTemperature.text = String(describing: viewModel?.highestTemperature)
            
        } else {
            // create the alert
            let alert = UIAlertController(title: "API Problem", message: "There seems to be a problem requesting the data would you like to retry?", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: nil))
            alert.addAction(UIAlertAction(title: "Retry", style: UIAlertAction.Style.default, handler: { action in
                // Try again to request API
                self.viewModel? = LocalWeatherViewModel(locationID: "4118")
                self.setupView()
            }))
            self.present(alert, animated: true, completion: nil)
        }
        
    }

}

