Hello, 


The timer is about 2:30 hours, so I thought it would be best to start the README file. 
Starting with my experience in general, I haven't done an API request is a while, so I had to research it again and watched this tutorial https://www.youtube.com/watch?v=tdxKIPpPDAI. 
But I believe my request wasn't working because of the Async response, I'm still improving my knowledge on working with threads so I think that was the main reason I couldn't complete it in the 2h.


- I opted for am MVVM architecture because I believe it is more organized, so I began working in the view on a StoryBoard to make a quick wireframe MVP but if I had more time I would rebuild it with ViewCode because it is way easier to maintain and is scalable to work in teams avoiding conflicts during rebases. 
- I also find that MVVM is easier to test since we can mock the ViewModel to test the View and mock the data and services to test the ViewModel, but I just didn't have time to make the UnitTests.


- The project doesn't have any special setup and I didn't use any 3rd party libraries. 


I'm always trying to improve so if you have any feedback on what I could have done differently or know of any interesting course or book, please feel free to contact me. 
LucasCavalcanteDeBarros@gmail.com