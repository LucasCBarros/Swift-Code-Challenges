import Foundation

//MARK: Step 1

//func Add(numbers: String) -> Int {
//    var sum = 0
////    let numbersWithoutEmptyspaces = numbers.replacingOccurrences(of: " ", with: "")
//    let numbersArray = numbers.components(separatedBy: ",")
//
//    for number in numbersArray {
//        if let intNumber = Int(number) {
//            sum += intNumber
//        }
//    }
//
//    return sum
//}
//
//Add(numbers: "1,2,3,4,5")
//Add(numbers: "1,2,3, 4, 5")
//Add(numbers: "")

//MARK: Step 2

//func AddWithLinebreak(numbers: String) -> Int {
//    var sum = 0
//    let numbersWithoutBreakline = numbers.replacingOccurrences(of: "\n", with: "")
//    let numbersArray = numbersWithoutBreakline.components(separatedBy: ",")
//
//
//    for number in numbersArray {
//        if let intNumber = Int(number) {
//            sum += intNumber
//        }
//    }
//
//    return sum
//}
//
//Add(numbers: "1,2,3,\n4,5")
//Add(numbers: "\n1")
//AddWithLinebreak(numbers: "1,2,3,\n4,5")
//AddWithLinebreak(numbers: "\n1")

//MARK: Step 3

//func AddWithDelimiter(numbers: String) -> Int {
//    // Result always starts at zero
//    var sum = 0
//
//    // Find the delimiter to be used
//    let delimiterChar = String(numbers[numbers.index(numbers.startIndex, offsetBy: 2)])
//
//    // Remove line break from string
//    let numbersWithoutBreakline = numbers.replacingOccurrences(of: "\n", with: "")
//
//    // Transform the string into a array of strings
//    let numbersArray = numbersWithoutBreakline.components(separatedBy: delimiterChar)
//
//    // Interates all numbers in array
//    for number in numbersArray {
//        // Converts the number Strings into Integers
//        if let intNumber = Int(number) {
//            sum += intNumber
//        }
//    }
//    return sum
//}
//
//AddWithDelimiter(numbers: "//$\n1$2$3") // 6
//AddWithDelimiter(numbers: "//@\n2@3@8") // 13
//AddWithDelimiter(numbers: "//;\n1;3;4") // 8

//MARK: Step 4

//func AddWithoutNegative(numbers: String) -> Int {
//    // Result always starts at zero
//    var sum = 0
//
//    var negativeNumbers = ""
//
//    // Find the delimiter to be used
//    let delimiterChar = String(numbers[numbers.index(numbers.startIndex, offsetBy: 2)])
//
//    // Remove line break from string
//    let numbersWithoutBreakline = numbers.replacingOccurrences(of: "\n", with: "")
//
//    // Transform the string into a array of strings
//    let numbersArray = numbersWithoutBreakline.components(separatedBy: delimiterChar)
//
//    // Interates all numbers in array
//    for number in numbersArray {
//        // Converts the number Strings into Integers
//        if let intNumber = Int(number) {
//
//            // Check IF number is positive THEN add to result
//            if intNumber > 0 {
//                sum += intNumber
//
//            // ELSE add to negative numbers list
//            } else {
//                negativeNumbers += ",\(intNumber)"
//                print("Negatives not allowed, please remove the numbers: \(negativeNumbers)")
//            }
//        }
//    }
//    return sum
//}
//
//AddWithoutNegative(numbers: "//$\n1$-2$3") // 4
//AddWithoutNegative(numbers: "//@\n-9@3@8") // 11
//AddWithoutNegative(numbers: "//;\n1;3;-4") // 4

//MARK: Step Bonus

func AddBonus(numbers: String) -> Int {
    // Result always starts at zero
    var sum = 0
    var negativeNumbers = ""
    
    // Find the delimiter to be used
    let delimiterStringList = slice(numbers, from: "//", to: "\n")?.components(separatedBy: ",")
    
    // Only the numbers after break line should be used for the sum
    let numbersStrings = numbers[(numbers.firstIndex(of: "\n") ?? numbers.startIndex)...]
    
    // REMOVE line break from string
    var numbersWithoutBreakline = numbersStrings.replacingOccurrences(of: "\n", with: "")
    
    // Prepare the string to be separated making all delimiters equal
    delimiterStringList?.forEach({ delimiter in
        numbersWithoutBreakline = numbersWithoutBreakline.replacingOccurrences(of: delimiter, with: ",")
    })
    
    // Transform the string into a array of strings
    let numbersArray = numbersWithoutBreakline.components(separatedBy: ",")

    // Interates all numbers in array
    for number in numbersArray {
        // Converts the number Strings into Integers
        if let intNumber = Int(number) {
            
            // Check IF number is positive THEN add to result
            if intNumber >= 0 {
                if intNumber < 1000 {
                    sum += intNumber
                }
            // ELSE add to negative numbers list
            } else {
                negativeNumbers += "\(intNumber) "
                print("Negatives not allowed, please remove the numbers: \(negativeNumbers)")
            }
        }
    }
    return sum
}

// Get string between two sets of strings
func slice(_ string: String, from: String, to: String) -> String? {
    guard let rangeFrom = string.range(of: from)?.upperBound else { return nil }
    guard let rangeTo = string[rangeFrom...].range(of: to)?.lowerBound else { return nil }
    return String(string[rangeFrom..<rangeTo])
}

//MARK: Bonus 1 - Ignores numbers bigger than 1000
AddBonus(numbers: "2,1001") // 2
AddBonus(numbers: "//;\n1;3;1001;-1") // 4

//MARK: Bonus 2 - Delimiters with arbitrary lenght
AddBonus(numbers: "//***\n1***2***3") // 16

//MARK: Bonus 3 - List of delimiters
AddBonus(numbers: "//$,@\n1$2@3") // 6

//MARK: Bonus 4 - List of delimiters with arbitraty lenghts
AddBonus(numbers: "//$$,@@\n1$$2@@3") // 6
