import Foundation

//MARK: Step 1

func Add(numbers: String) -> Int {
    var sum = 0
    let numbersArray = numbers.components(separatedBy: ",")

    for number in numbersArray {
        if let intNumber = Int(number) {
            sum += intNumber
        }
    }

    return sum
}

// MARK: - Tests Cases

Add(numbers: "1,2,3,4,5") // 15
Add(numbers: "1,2,3,4,5,100") // 115
Add(numbers: "") // 0
