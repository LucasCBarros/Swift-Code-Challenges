import Foundation

//MARK: Step 2

func AddWithLinebreak(numbers: String) -> Int {
    var sum = 0
    let numbersWithoutBreakline = numbers.replacingOccurrences(of: "\n", with: "")
    let numbersArray = numbersWithoutBreakline.components(separatedBy: ",")


    for number in numbersArray {
        if let intNumber = Int(number) {
            sum += intNumber
        }
    }

    return sum
}

// MARK: - Tests Cases

AddWithLinebreak(numbers: "1,2,3,\n4,5") // 15
AddWithLinebreak(numbers: "\n1") // 1
