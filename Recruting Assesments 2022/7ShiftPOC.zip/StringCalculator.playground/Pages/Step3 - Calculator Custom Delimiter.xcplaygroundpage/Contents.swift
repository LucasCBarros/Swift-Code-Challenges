import Foundation

//MARK: Step 3

func AddWithDelimiter(numbers: String) -> Int {
    // Result always starts at zero
    var sum = 0

    // Find the delimiter to be used
    let delimiterChar = String(numbers[numbers.index(numbers.startIndex, offsetBy: 2)])

    // Remove line break from string
    let numbersWithoutBreakline = numbers.replacingOccurrences(of: "\n", with: "")

    // Transform the string into a array of strings
    let numbersArray = numbersWithoutBreakline.components(separatedBy: delimiterChar)

    // Interates all numbers in array
    for number in numbersArray {
        // Converts the number Strings into Integers
        if let intNumber = Int(number) {
            sum += intNumber
        }
    }
    return sum
}

// MARK: - Tests Cases

AddWithDelimiter(numbers: "//$\n1$2$3") // 6
AddWithDelimiter(numbers: "//@\n2@3@8") // 13
AddWithDelimiter(numbers: "//;\n1;3;4") // 8
