import Foundation

//MARK: Step 4

func AddWithoutNegative(numbers: String) throws -> Int {
    // Result always starts at zero
    var sum = 0

    var negativeNumbers = ""

    // Find the delimiter to be used
    let delimiterChar = String(numbers[numbers.index(numbers.startIndex, offsetBy: 2)])

    // Remove line break from string
    let numbersWithoutBreakline = numbers.replacingOccurrences(of: "\n", with: "")

    // Transform the string into a array of strings
    let numbersArray = numbersWithoutBreakline.components(separatedBy: delimiterChar)

    // Interates all numbers in array
    for number in numbersArray {
        // Converts the number Strings into Integers
        if let intNumber = Int(number) {

            // Check IF number is positive THEN add to result
            if intNumber >= 0 {
                sum += intNumber
            } else {
                negativeNumbers += "\(intNumber) "
            }
        }
    }
    
    guard negativeNumbers.isEmpty else {
        throw ValidationError.negativeNumbers("Negatives not allowed, please remove the numbers: \(negativeNumbers)")
    }
    
    return sum
}

// Possible errors in the calculator
enum ValidationError: Error {
    case negativeNumbers(_ numbers: String)
}

// MARK: - Tests Cases

//try AddWithoutNegative(numbers: "//$\n1$-2$3$-1$-0$-10")
//try AddWithoutNegative(numbers: "//@\n-9@3@8")
//try AddWithoutNegative(numbers: "//;\n1;5;-4")
try AddWithoutNegative(numbers: "//;\n;;")
//try AddWithoutNegative(numbers: "//;\n1;5;4")
