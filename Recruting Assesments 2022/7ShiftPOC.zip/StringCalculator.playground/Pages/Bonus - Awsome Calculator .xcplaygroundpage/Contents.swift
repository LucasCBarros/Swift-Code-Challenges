import Foundation

//MARK: Step Bonus

func AddBonus(numbers: String) throws -> Int {
    // Result always starts at zero
    var sum = 0
    var negativeNumbers = ""
    
    // Find the delimiter to be used
    let delimiterStringList = slice(numbers, from: "//", to: "\n")?.components(separatedBy: ",")
    
    // Only the numbers after break line should be used for the sum
    let numbersStrings = numbers[(numbers.firstIndex(of: "\n") ?? numbers.startIndex)...]
    
    // REMOVE line break from string
    var numbersWithoutBreakline = numbersStrings.replacingOccurrences(of: "\n", with: "")
    
    // Prepare the string to be separated making all delimiters equal
    delimiterStringList?.forEach({ delimiter in
        numbersWithoutBreakline = numbersWithoutBreakline.replacingOccurrences(of: delimiter, with: ",")
    })
    
    // Transform the string into a array of strings
    let numbersArray = numbersWithoutBreakline.components(separatedBy: ",")
    
    // Validade if there are numbers in string
    guard !numbersArray.isEmpty else {
        print(numbersArray)
        throw ValidationError.noNumbersInsideString("There are no numbers in the string")
    }

    // Interates all numbers in array
    for number in numbersArray {
        // Converts the number Strings into Integers
        if let intNumber = Int(number) {
            
            // Check IF number is positive THEN add to result
            if intNumber >= 0 {
                if intNumber < 1000 {
                    sum += intNumber
                }
            // ELSE add to negative numbers list
            } else {
                negativeNumbers += "\(intNumber) "
                print("Negatives not allowed, please remove the numbers: \(negativeNumbers)")
            }
        }
    }
    
    // Validade if there are negative numbers in string
    guard negativeNumbers.isEmpty else {
        throw ValidationError.negativeNumbers("Negatives not allowed, please remove the numbers: \(negativeNumbers)")
    }
    
    return sum
}

// Possible errors in the Awsome Calculator
enum ValidationError: Error {
    case negativeNumbers(_ numbers: String)
    case noNumbersInsideString(_ message: String)
}

// Get string between two sets of strings
func slice(_ string: String, from: String, to: String) -> String? {
    guard let rangeFrom = string.range(of: from)?.upperBound else { return nil }
    guard let rangeTo = string[rangeFrom...].range(of: to)?.lowerBound else { return nil }
    return String(string[rangeFrom..<rangeTo])
}
    
// MARK: - Tests Cases

//MARK: Bonus 1 - Ignores numbers bigger than 1000
//try AddBonus(numbers: "2,1001") // 2
//try AddBonus(numbers: "//;\n1;3;1001;-1") // 4

//MARK: Bonus 2 - Delimiters with arbitrary lenght
//try AddBonus(numbers: "//***\n1***2***3") // 16

//MARK: Bonus 3 - List of delimiters
//try AddBonus(numbers: "//$,@\n1$2@3") // 6

//MARK: Bonus 4 - List of delimiters with arbitraty lenghts
try AddBonus(numbers: "//$$,@@\n1$$2@@3") // 6
